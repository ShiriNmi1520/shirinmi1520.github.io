$(document).ready(function() {
  function getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(getPos);
    } else {
      alert("瀏覽器不支援定位功能!");
    }
  }
  function getPos(position) {
    sessionStorage.setItem("latitude", position.coords.latitude);
    sessionStorage.setItem("longitude", position.coords.longitude);
  }
  function updateTable(data, filter = false) {
    $("#sailorTable tbody").empty();
    $("table").show();
    if (filter) {
      for (index in data) {
        console.log(data[index]);
        if ($("#star").val() == "1") {
          if (data[index].rating < 3) continue;
          else {
            var td1 = $("<td>").text(data[index].name);
            var td2 = $("<td>").text(data[index].opening ? "營業中" : "未營業");
            var td3 = $("<td>").text(data[index].address);
            var td4 = $("<td>").text(data[index].rating);
            var td5 = $("<td>").text(data[index].ratingCount);
            var tr = $("<tr>").append(td1, td2, td3, td4, td5);
            $("table").append(tr);
          }
        }
        if ($("#star").val() == "2") {
          if (data[index].rating < 4) continue;
          else {
            var td1 = $("<td>").text(data[index].name);
            var td2 = $("<td>").text(data[index].opening ? "營業中" : "未營業");
            var td3 = $("<td>").text(data[index].address);
            var td4 = $("<td>").text(data[index].rating);
            var td5 = $("<td>").text(data[index].ratingCount);
            var tr = $("<tr>").append(td1, td2, td3, td4, td5);
            $("table").append(tr);
          }
        } else {
          var td1 = $("<td>").text(data[index].name);
          var td2 = $("<td>").text(data[index].opening ? "營業中" : "未營業");
          var td3 = $("<td>").text(data[index].address);
          var td4 = $("<td>").text(data[index].rating);
          var td5 = $("<td>").text(data[index].ratingCount);
          var tr = $("<tr>").append(td1, td2, td3, td4, td5);
          $("table").append(tr);
        }
      }
    } else {
      for (index in data) {
        console.log(data[index]);
        var td1 = $("<td>").text(data[index].name);
        var td2 = $("<td>").text(data[index].opening ? "營業中" : "未營業");
        var td3 = $("<td>").text(data[index].address);
        var td4 = $("<td>").text(data[index].rating);
        var td5 = $("<td>").text(data[index].ratingCount);
        var tr = $("<tr>").append(td1, td2, td3, td4, td5);
        $("table").append(tr);
      }
    }
  }

  $("#submit").click(function() {
    var distance = 0;
    distance = $("#distance").val();
    if($("#distance").val().trim() == ""){distance = 500;}
    getLocation();
    console.log(distance);
    $.ajax({
      type: "GET",
      url: "https://enigmatic-chamber-09650.herokuapp.com/search/food",
      data: {
        distance: distance,
        latitude: sessionStorage.getItem("latitude"),
        longitude: sessionStorage.getItem("longitude"),
        keyword: $("#simpleSearch").val()
      },
      headers: {
        "X-Auth-Token": sessionStorage.getItem("token")
      },
      async: true,
      success: function(data) {
        if (data.count == 0) {
          alert("查無資料!");
          $("#sailorTable tbody").empty();
          $("table").show();
          var td1 = $("<td>").text("查無資料");
          var td2 = $("<td>").text("查無資料");
          var td3 = $("<td>").text("查無資料");
          var td4 = $("<td>").text("查無資料");
          var td5 = $("<td>").text("查無資料");
          var tr = $("<tr>").append(td1, td2, td3, td4, td5);
          $("table").append(tr);
        } else {
          updateTable(data.data);
        }
      },
      error: function(data) {}
    });
  });
  // $("#submit1").click(function() {
  //   getLocation();
  //   $.ajax({
  //     type: "GET",
  //     url: "https://enigmatic-chamber-09650.herokuapp.com/search/food",
  //     data: {
  //       distance: $("#distance").val(),
  //       latitude: sessionStorage.getItem("latitude"),
  //       longitude: sessionStorage.getItem("longitude"),
  //       keyword: $("#simpleSearch").val()
  //     },
  //     headers: {
  //       "X-Auth-Token": sessionStorage.getItem("token")
  //     },
  //     async: true,
  //     success: function(data) {
  //       if (data.count == 0) {
  //         alert("查無資料!");
  //         $("#sailorTable tbody").empty();
  //         $("table").show();
  //         var td1 = $("<td>").text("查無資料");
  //         var td2 = $("<td>").text("查無資料");
  //         var td3 = $("<td>").text("查無資料");
  //         var td4 = $("<td>").text("查無資料");
  //         var td5 = $("<td>").text("查無資料");
  //         var tr = $("<tr>").append(td1, td2, td3, td4, td5);
  //         $("table").append(tr);
  //       } else {
  //         updateTable(data.data, true);
  //       }
  //     },
  //     error: function(data) {}
  //   });
  // });
});
